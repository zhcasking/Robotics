# Practice3

## Usage 

1. quadcopter hovering example
```bash=
$ python3 quadcopter_hover.py
```
![](https://i.imgur.com/HoeJZGA.png)

2. quadcopter trajectory tracking example
```bash=
$ python3 quadcopter_trajectory.py
```
![](https://i.imgur.com/wOpcClr.png)
